rai1 = [0, 0];
vai1 = [20, 0, 2];
rbi1 = [100, 100];
vbi1 = [0, -20, -1];
tb1 = 0.0;

rai2 = [0, 0];
vai2 = [30, 0, 2];
rbi2 = [100, 100];
vbi2 = [0, -30, -1];
tb2 = 0.0;

rai3 = [0, 0];
vai3 = [20, 0, 2];
rbi3 = [100, 50];
vbi3 = [0, -10, 0];
tb3 = 1.6;

rai4 = [0, 0];
vai4 = [10, 10, 1];
rbi4 = [25, 10];
vbi4 = [10, 0, 0];
tb4 = 0.0;

rai5 = [0, 0];
vai5 = [20, 0, 2];
rbi5 = [100, 50];
vbi5 = [0, -10, 0];
tb5 = 0.0;

rai6 = [0, 0];
vai6 = [20, 2, 2];
rbi6 = [100, 10];
vbi6 = [10, 0, 5];
tb6 = 1.0;

[coll1 tf1 raf1 vaf1 rbf1 vbf1] = Devoir3(rai1, vai1, rbi1, vbi1, tb1);

[coll2 tf2 raf2 vaf2 rbf2 vbf2] = Devoir3(rai2, vai2, rbi2, vbi2, tb2);

[coll3 tf3 raf3 vaf3 rbf3 vbf3] = Devoir3(rai3, vai3, rbi3, vbi3, tb3);

[coll4 tf4 raf4 vaf4 rbf4 vbf4] = Devoir3(rai4, vai4, rbi4, vbi4, tb4);

[coll5 tf5 raf5 vaf5 rbf5 vbf5] = Devoir3(rai5, vai5, rbi5, vbi5, tb5);

[coll6 tf6 raf6 vaf6 rbf6 vbf6] = Devoir3(rai6, vai6, rbi6, vbi6, tb6);